<?php
header("location:/");
?>