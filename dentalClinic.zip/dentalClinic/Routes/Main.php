<?php

/**
 * @package Routes
 * @Caution Heavy use of closures Ahead
 **/

$Service->enable_route('System','Custom','VA/Main','Sandbox');
// $Service->enable_route('VA/Main');
?>