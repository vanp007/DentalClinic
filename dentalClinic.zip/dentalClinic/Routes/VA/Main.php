<?php
/**
 * @package Routes 
 **/
$Router->get('/',function() use ($Service) { 
	include('Views/VA/index.html');
});

$Router->get('/admini',function() use ($Service){
	include('Views/VA/admini.php');
});

$Router->post('/admini',function()use ($Service){

	$username = $_POST['username'];
	$password = $_POST['password'];
	
	if($username && $password) {
		if($user = $Service->Prote()->DBI()->DbHelper()->user()->IsUserValid($username, $password)) {
			echo $user->username;
		} else {
			echo "Invalid username or password. Please try again!";
		}
	}

	
});

$Router->get('/pregistration',function()use ($Service){
	include('Views/VA/pregistration.php');
});

$Router->get('/uses',function()use ($Service){
	include('Views/VA/uses.php');
});

$Router->get('/summary',function()use ($Service){
	include('Views/VA/summary.php');
});
