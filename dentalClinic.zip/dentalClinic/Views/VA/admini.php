<?php 
	include"header.php";

 ?>

<div class="container">
	<div class="row text-center my-4">
		<div class="col-12">
			<h1 style="font-weight: bolder; font-size: 50px; color: #03A13B;">Admin Panel</h1>
		</div></div>
	<div class="row text-center my-4">
		<div class="col-6 my-4">
			<a href="/pregistration"><button class="btn btn-primary btn-lg w-75">REGISTER <br>NEW PATIENT</button></a>
		</div>

		<div class="col-6 my-4">
			<a href="/uses"><button class="btn btn-primary btn-lg w-75">RECORD <br>DAILY USES</button></a>
		</div>
	</div>
	<div class="row text-center my-4">
		<div class="col-12 my-4">
			<a href="/summary"><button class="btn btn-primary btn-lg w-75"> VIEW AND PRINT <br> SUMMARY<br></button></a>
		</div>
		
	</div>

</div>
</body>
</html>