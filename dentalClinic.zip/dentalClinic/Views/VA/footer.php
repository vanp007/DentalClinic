</body>
 <footer class="page-footer">
          <div class="container">
            <div class="row">
              <div class="col m6 s12">
                <h5 class="white-text"><i class="material-icons">location_on</i> Address</h5>
                <p class="grey-text text-lighten-4">
                	Shop #107, VPO Jamalpur<br>
                	Chowk, Pataudi Road, <br>
                	Gurugram, Haryana
                </p>
              </div>
              <div class="col m6 s12">
                <h5 class="white-text"><i class="material-icons">contacts</i> Contact us</h5>
                <p class="grey-text text-lighten-4">
                	<ul>
                		<li><u>Email</u> : info@dharmendertransport.in</li>
                		<li><u>Phone</u> :+91 9992332289, +91 9992477754</li>
                	</ul>
                </p>
              </div>
            </div>
          </div>
          <div class="footer-copyright">
            <div class="container">
            © 2019 Dharmender transport
            </div>
          </div>
</footer>