<!DOCTYPE html>
<html>
<head>
    <title></title>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    
    <link rel="stylesheet" type="text/css" href="../../Static/va/bcss/bootstrap.css">
    <link rel="stylesheet" type="" href="../../Static/va/fontawesome/css/all.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script type="text/javascript" src="../../static/va/js/bootstrap.js"></script>
    <script src="https://use.fontawesome.com/releases/v5.0.8/js/all.js"></script>
    <link rel="stylesheet" type="text/css" href="../../static/va/css/style.css">
</head>
<body style="background-color: silver;">

<div class="container-fluid text-center">
  <div class="row">
    <div class="col-12 bg-secondary">
      <h1 class="display-4">Abcde Dental Clinic Management System</h1>
    </div>
  </div>
</div>